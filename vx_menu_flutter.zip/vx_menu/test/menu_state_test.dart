import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:vx_menu/core/constants.dart';
import 'package:vx_menu/core/prefs_store.dart';
import 'package:vx_menu/state/menu_state.dart';

void main() {
  test('persiste e restaura preferências', () async {
    SharedPreferences.setMockInitialValues({});
    final s1 = MenuState(await PrefsStore.open());
    s1.set(K.aimFov, 120.0);
    s1.set(K.espOn, true);
    await Future<void>.delayed(Duration.zero);

    final s2 = MenuState(await PrefsStore.open());
    expect(s2.dbl(K.aimFov), 120.0);
    expect(s2.flag(K.espOn), true);
  });

  test('perfil Completo liga todos os módulos', () async {
    SharedPreferences.setMockInitialValues({});
    final s = MenuState(await PrefsStore.open());
    s.applyProfile(2);
    expect(s.activeModules, 7);
  });
}

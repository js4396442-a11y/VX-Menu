# VX Menu — interface de demonstração (Flutter / Android)

Menu flutuante dark (preto, grafite, vermelho neon) com abas **HOME · AIM · VISUAL · SETTINGS**.

## O que este app é (e não é)

É um aplicativo **independente**: uma interface/protótipo com estado e persistência local.
Os toggles e sliders de AIM e VISUAL controlam **simulações dentro do próprio app**
(prévia com alvos e bonecos fictícios). O app **não** injeta código, **não** lê nem escreve
memória de outros processos, **não** toca em arquivos de nenhum jogo e **não** interage com
anticheat. Não pede nenhuma permissão especial (nem sobreposição, nem acessibilidade).

## Funcionalidades

- Janela arrastável (pelo cabeçalho), minimizar/expandir (botão `–` / bolha), posição salva.
- HOME: status, perfis de configuração (Padrão / Equilibrado / Completo), indicadores, info do app.
- AIM: Aim Assist, FOV, Smoothness, Target Selection, Aim Mode — com prévia animada.
- VISUAL: ESP, Player Box, Skeleton, Name, Distance, Radar — com prévia animada.
- SETTINGS: escala, opacidade, tema (4 cores), posição (5 presets), animações, hotkeys (teclado físico).
- Todas as preferências são salvas localmente (`shared_preferences`).

## Arquitetura

```
lib/
├── main.dart                 # bootstrap + MaterialApp
├── app/
│   ├── menu_shell.dart       # palco, drag, minimizar, hotkeys, escala responsiva
│   └── menu_window.dart      # cabeçalho, abas, troca de páginas
├── core/
│   ├── constants.dart        # chaves (K), defaults, perfis, presets
│   ├── theme.dart            # paleta, temas de destaque, ThemeData
│   ├── prefs_store.dart      # persistência local
│   └── paint_utils.dart      # texto/grade para CustomPainter
├── state/
│   ├── menu_state.dart       # ChangeNotifier único (flag/dbl/idx/set/save)
│   └── menu_scope.dart       # InheritedNotifier (acesso via MenuScope.of)
├── pages/                    # home, aim, visual, settings
└── widgets/                  # NeonCard, NeonToggle, NeonSlider, NeonSelector,
                              # PulseDot, AimPreview, VisualPreview
```

## Compilar o APK

Pré-requisitos: [Flutter SDK](https://docs.flutter.dev/get-started/install) (3.22+), Android SDK
(`flutter doctor` sem erros) e um aparelho ou emulador.

```bash
cd vx_menu

# 1) gera a pasta android/ (mantém lib/ e pubspec.yaml)
flutter create --platforms=android --org com.example --project-name vx_menu .

# 2) apague o teste padrão gerado (ele referencia MyApp)
rm test/widget_test.dart

# 3) dependências
flutter pub get

# 4) (opcional) conferir e testar
flutter analyze
flutter test

# 5) rodar em um aparelho/emulador
flutter run

# 6) gerar o APK
flutter build apk --release
# saída: build/app/outputs/flutter-apk/app-release.apk

# APKs menores, um por arquitetura:
flutter build apk --release --split-per-abi
```

Dicas:
- Nome do app na tela inicial: edite `android:label` em `android/app/src/main/AndroidManifest.xml`.
- O build `release` do template usa a chave de debug. Para distribuir, crie um keystore e
  configure a assinatura: https://docs.flutter.dev/deployment/android#sign-the-app
- Instalar no celular: `adb install build/app/outputs/flutter-apk/app-release.apk`.

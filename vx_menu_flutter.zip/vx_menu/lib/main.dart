import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'app/menu_shell.dart';
import 'core/constants.dart';
import 'core/prefs_store.dart';
import 'core/theme.dart';
import 'state/menu_scope.dart';
import 'state/menu_state.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    statusBarIconBrightness: Brightness.light,
    systemNavigationBarColor: Colors.transparent,
    systemNavigationBarIconBrightness: Brightness.light,
  ));
  final store = await PrefsStore.open();
  runApp(VxApp(state: MenuState(store)));
}

class VxApp extends StatelessWidget {
  const VxApp({super.key, required this.state});
  final MenuState state;

  @override
  Widget build(BuildContext context) {
    return MenuScope(
      state: state,
      child: Builder(builder: (context) {
        final s = MenuScope.of(context);
        return MaterialApp(
          debugShowCheckedModeBanner: false,
          title: 'VX Menu',
          theme: buildTheme(s.idx(K.theme)),
          home: const MenuShell(),
        );
      }),
    );
  }
}

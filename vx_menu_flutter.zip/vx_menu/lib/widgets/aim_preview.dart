import 'dart:math' as math;
import 'package:flutter/material.dart';

import '../core/constants.dart';
import '../core/paint_utils.dart';
import '../core/theme.dart';
import '../state/menu_scope.dart';
import '../state/menu_state.dart';

class _Target {
  const _Target(this.hp, this.dist, this.cx, this.cy, this.rx, this.ry,
      this.sp, this.ph);
  final int hp, dist;
  final double cx, cy, rx, ry, sp, ph;

  Offset at(double t, Size sz) => Offset(
        sz.width * (cx + rx * math.cos(t * sp * .6 + ph)),
        sz.height * (cy + ry * math.sin(t * sp * .5 + ph)),
      );
}

const _targets = [
  _Target(90, 35, .30, .50, .22, .25, 1.0, 0),
  _Target(40, 18, .70, .45, .20, .30, 1.4, 2),
  _Target(70, 60, .50, .60, .35, .20, 0.8, 4),
];

/// Pré-visualização 100% local: um "alvo de treino" fictício que mostra o
/// efeito de FOV, suavidade, seleção de alvo e modo. Não lê nem altera nada
/// fora deste app.
class AimPreview extends StatefulWidget {
  const AimPreview({super.key});
  @override
  State<AimPreview> createState() => _AimPreviewState();
}

class _AimPreviewState extends State<AimPreview>
    with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(
      vsync: this, duration: const Duration(days: 1))
    ..addListener(_step)
    ..repeat();

  late MenuState _s;
  Size _size = Size.zero;
  Offset _cross = Offset.zero;
  bool _inited = false;
  bool _holding = false;
  bool _latched = false;
  int? _sel;
  double _radius = 0;
  bool _active = false;
  List<Offset> _pos = const [];

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _s = MenuScope.of(context);
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  void _step() {
    if (_size.isEmpty) return;
    final center = _size.center(Offset.zero);
    if (!_inited) {
      _cross = center;
      _inited = true;
    }
    final s = _s;
    final time = _c.value * 86400.0;
    _pos = [for (final t in _targets) t.at(time, _size)];

    final mode = s.idx(K.aimMode);
    _active = s.flag(K.aimOn) &&
        (mode == 0 || (mode == 1 && _holding) || (mode == 2 && _latched));
    _radius = s.dbl(K.aimFov) / 180 * _size.shortestSide * .48;

    int? best;
    var bestScore = double.infinity;
    for (var i = 0; i < _targets.length; i++) {
      final d = (_pos[i] - center).distance;
      if (d > _radius) continue;
      final score = switch (s.idx(K.aimTarget)) {
        0 => d,
        1 => _targets[i].dist.toDouble(),
        _ => _targets[i].hp.toDouble(),
      };
      if (score < bestScore) {
        bestScore = score;
        best = i;
      }
    }
    _sel = _active ? best : null;
    final goal = _sel == null ? center : _pos[_sel!];
    final f = .02 + (1 - s.dbl(K.aimSmooth) / 100) * .25;
    _cross = Offset.lerp(_cross, goal, f)!;
  }

  @override
  Widget build(BuildContext context) {
    final s = MenuScope.of(context);
    final accent = Theme.of(context).colorScheme.primary;
    final hint = switch (s.idx(K.aimMode)) {
      0 => 'Contínuo · sempre ativo',
      1 => 'Segurar · mantenha o dedo aqui',
      _ => 'Alternar · toque para ligar/desligar',
    };

    return ClipRRect(
      borderRadius: BorderRadius.circular(8),
      child: SizedBox(
        height: 150,
        child: Listener(
          behavior: HitTestBehavior.opaque,
          onPointerDown: (_) {
            _holding = true;
            _latched = !_latched;
          },
          onPointerUp: (_) => _holding = false,
          onPointerCancel: (_) => _holding = false,
          child: Stack(children: [
            Positioned.fill(
              child: LayoutBuilder(builder: (context, box) {
                _size = Size(box.maxWidth, box.maxHeight);
                return AnimatedBuilder(
                  animation: _c,
                  builder: (_, __) => CustomPaint(
                    size: Size.infinite,
                    painter: _AimPainter(
                      accent: accent,
                      enabled: s.flag(K.aimOn),
                      active: _active,
                      cross: _inited ? _cross : _size.center(Offset.zero),
                      pos: _pos,
                      radius: _radius,
                      sel: _sel,
                    ),
                  ),
                );
              }),
            ),
            Positioned(
              left: 8,
              bottom: 6,
              child: Text(
                s.flag(K.aimOn) ? hint : 'Aim Assist desligado',
                style: const TextStyle(fontSize: 9, color: Palette.muted),
              ),
            ),
          ]),
        ),
      ),
    );
  }
}

class _AimPainter extends CustomPainter {
  _AimPainter({
    required this.accent,
    required this.enabled,
    required this.active,
    required this.cross,
    required this.pos,
    required this.radius,
    required this.sel,
  });

  final Color accent;
  final bool enabled, active;
  final Offset cross;
  final List<Offset> pos;
  final double radius;
  final int? sel;

  @override
  void paint(Canvas canvas, Size size) {
    canvas.drawRect(Offset.zero & size, Paint()..color = Palette.bg);
    paintGrid(canvas, size);
    final center = size.center(Offset.zero);

    if (enabled) {
      canvas.drawCircle(center, radius, Paint()..color = accent.o(.06));
      canvas.drawCircle(
        center,
        radius,
        Paint()
          ..color = accent.o(.7)
          ..style = PaintingStyle.stroke
          ..strokeWidth = 1.2,
      );
    }

    for (var i = 0; i < pos.length; i++) {
      final isSel = i == sel;
      canvas.drawCircle(pos[i], 8,
          Paint()..color = isSel ? accent : const Color(0xFF3A3A46));
      paintText(canvas, '${_targets[i].hp}hp · ${_targets[i].dist}m',
          pos[i] + const Offset(0, -16),
          size: 8.5, color: isSel ? Palette.text : Palette.muted);
    }

    if (sel != null && active) {
      canvas.drawLine(
        cross,
        pos[sel!],
        Paint()
          ..color = accent.o(.5)
          ..strokeWidth = 1,
      );
    }

    final ch = Paint()
      ..color = Palette.text
      ..strokeWidth = 1.4;
    canvas.drawLine(cross + const Offset(-8, 0), cross + const Offset(-3, 0), ch);
    canvas.drawLine(cross + const Offset(3, 0), cross + const Offset(8, 0), ch);
    canvas.drawLine(cross + const Offset(0, -8), cross + const Offset(0, -3), ch);
    canvas.drawLine(cross + const Offset(0, 3), cross + const Offset(0, 8), ch);
    canvas.drawCircle(cross, 1.4, Paint()..color = accent);
  }

  @override
  bool shouldRepaint(covariant _AimPainter old) => true;
}

import 'package:flutter/material.dart';
import '../core/theme.dart';
import '../state/menu_scope.dart';

class NeonToggle extends StatelessWidget {
  const NeonToggle({
    super.key,
    required this.label,
    required this.value,
    required this.onChanged,
    this.icon,
    this.hint,
    this.enabled = true,
  });

  final String label;
  final String? hint;
  final IconData? icon;
  final bool value;
  final bool enabled;
  final ValueChanged<bool> onChanged;

  @override
  Widget build(BuildContext context) {
    final s = MenuScope.of(context);
    final accent = Theme.of(context).colorScheme.primary;
    final dur = s.d(180);

    return Semantics(
      toggled: value,
      label: label,
      child: Opacity(
        opacity: enabled ? 1 : .38,
        child: GestureDetector(
          behavior: HitTestBehavior.opaque,
          onTap: enabled ? () => onChanged(!value) : null,
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 8),
            child: Row(children: [
              if (icon != null) ...[
                AnimatedContainer(
                  duration: dur,
                  child: Icon(icon,
                      size: 18, color: value ? accent : Palette.muted),
                ),
                const SizedBox(width: 10),
              ],
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(label,
                        style: const TextStyle(
                            fontSize: 12.5, fontWeight: FontWeight.w600)),
                    if (hint != null)
                      Text(hint!,
                          style: const TextStyle(
                              fontSize: 9.5, color: Palette.muted)),
                  ],
                ),
              ),
              AnimatedContainer(
                duration: dur,
                curve: Curves.easeOutCubic,
                width: 40,
                height: 22,
                padding: const EdgeInsets.all(3),
                decoration: BoxDecoration(
                  color: value ? accent.o(.22) : Palette.line,
                  borderRadius: BorderRadius.circular(11),
                  border: Border.all(color: value ? accent : Palette.line),
                  boxShadow: value
                      ? [BoxShadow(color: accent.o(.45), blurRadius: 10)]
                      : const [],
                ),
                child: AnimatedAlign(
                  duration: dur,
                  curve: Curves.easeOutCubic,
                  alignment:
                      value ? Alignment.centerRight : Alignment.centerLeft,
                  child: Container(
                    width: 14,
                    height: 14,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: value ? accent : Palette.muted,
                    ),
                  ),
                ),
              ),
            ]),
          ),
        ),
      ),
    );
  }
}

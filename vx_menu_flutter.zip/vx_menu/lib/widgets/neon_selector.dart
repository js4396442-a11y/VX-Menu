import 'package:flutter/material.dart';
import '../core/theme.dart';
import '../state/menu_scope.dart';

class NeonSelector extends StatelessWidget {
  const NeonSelector({
    super.key,
    required this.label,
    required this.options,
    required this.selected,
    required this.onChanged,
    this.colors,
  });

  final String label;
  final List<String> options;
  final int selected;
  final ValueChanged<int> onChanged;
  final List<Color>? colors;

  @override
  Widget build(BuildContext context) {
    final s = MenuScope.of(context);
    final accent = Theme.of(context).colorScheme.primary;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label,
            style:
                const TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600)),
        const SizedBox(height: 8),
        Wrap(spacing: 6, runSpacing: 6, children: [
          for (var i = 0; i < options.length; i++)
            GestureDetector(
              onTap: () => onChanged(i),
              child: AnimatedContainer(
                duration: s.d(160),
                padding:
                    const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                decoration: BoxDecoration(
                  color: i == selected ? accent.o(.14) : Palette.panel,
                  borderRadius: BorderRadius.circular(6),
                  border: Border.all(
                      color: i == selected ? accent : Palette.line),
                  boxShadow: i == selected
                      ? [BoxShadow(color: accent.o(.25), blurRadius: 8)]
                      : const [],
                ),
                child: Row(mainAxisSize: MainAxisSize.min, children: [
                  if (colors != null) ...[
                    Container(
                      width: 8,
                      height: 8,
                      decoration: BoxDecoration(
                          shape: BoxShape.circle, color: colors![i]),
                    ),
                    const SizedBox(width: 6),
                  ],
                  Text(options[i],
                      style: TextStyle(
                        fontSize: 10.5,
                        fontWeight: FontWeight.w600,
                        color: i == selected ? Palette.text : Palette.muted,
                      )),
                ]),
              ),
            ),
        ]),
      ],
    );
  }
}

import 'dart:math' as math;
import 'package:flutter/material.dart';

import '../core/constants.dart';
import '../core/paint_utils.dart';
import '../core/theme.dart';
import '../state/menu_scope.dart';

/// Pré-visualização 100% local com bonecos fictícios, para mostrar o efeito
/// de cada toggle (caixa, esqueleto, nome, distância, radar).
class VisualPreview extends StatefulWidget {
  const VisualPreview({super.key});
  @override
  State<VisualPreview> createState() => _VisualPreviewState();
}

class _VisualPreviewState extends State<VisualPreview>
    with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(
      vsync: this, duration: const Duration(seconds: 4));

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (MenuScope.of(context).anim) {
      if (!_c.isAnimating) _c.repeat();
    } else {
      _c.stop();
    }
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final s = MenuScope.of(context);
    final accent = Theme.of(context).colorScheme.primary;
    return ClipRRect(
      borderRadius: BorderRadius.circular(8),
      child: SizedBox(
        height: 160,
        child: AnimatedBuilder(
          animation: _c,
          builder: (_, __) => CustomPaint(
            size: Size.infinite,
            painter: _VisualPainter(
              accent: accent,
              esp: s.flag(K.espOn),
              box: s.flag(K.box),
              skeleton: s.flag(K.skeleton),
              name: s.flag(K.name),
              distance: s.flag(K.distance),
              radar: s.flag(K.radar),
              sweep: _c.value,
            ),
          ),
        ),
      ),
    );
  }
}

class _VisualPainter extends CustomPainter {
  _VisualPainter({
    required this.accent,
    required this.esp,
    required this.box,
    required this.skeleton,
    required this.name,
    required this.distance,
    required this.radar,
    required this.sweep,
  });

  final Color accent;
  final bool esp, box, skeleton, name, distance, radar;
  final double sweep;

  static const _people = <(double, double, String, int)>[
    (0.22, 0.80, 'Alpha', 42),
    (0.50, 1.00, 'Bravo', 18),
    (0.78, 0.65, 'Charlie', 75),
  ];

  @override
  void paint(Canvas canvas, Size size) {
    canvas.drawRect(Offset.zero & size, Paint()..color = Palette.bg);
    paintGrid(canvas, size);
    final ground = size.height * .86;

    for (final p in _people) {
      final (fx, k, label, dist) = p;
      final x = size.width * fx;
      final h = size.height * .62 * k;
      final top = ground - h;
      final w = h * .34;

      _body(canvas, x, top, h, w);
      if (!esp) continue;
      if (box) _box(canvas, Rect.fromLTWH(x - w / 2 - 5, top - 5, w + 10, h + 10));
      if (skeleton) _skeleton(canvas, x, top, h, w);
      if (name) {
        paintText(canvas, label, Offset(x, top - 14),
            size: 9, color: Palette.text, weight: FontWeight.w700);
      }
      if (distance) {
        paintText(canvas, '${dist}m', Offset(x, ground + 13),
            size: 9, color: accent);
      }
    }

    if (radar) _radar(canvas, size);
  }

  void _body(Canvas canvas, double x, double top, double h, double w) {
    final fill = Paint()..color = const Color(0xFF24242D);
    canvas.drawCircle(Offset(x, top + h * .07), h * .07, fill);
    canvas.drawRRect(
        RRect.fromRectAndRadius(
            Rect.fromLTWH(x - w / 2, top + h * .16, w, h * .40),
            const Radius.circular(5)),
        fill);
    canvas.drawRRect(
        RRect.fromRectAndRadius(
            Rect.fromLTWH(x - w * .46, top + h * .58, w * .40, h * .42),
            const Radius.circular(3)),
        fill);
    canvas.drawRRect(
        RRect.fromRectAndRadius(
            Rect.fromLTWH(x + w * .06, top + h * .58, w * .40, h * .42),
            const Radius.circular(3)),
        fill);
  }

  void _box(Canvas canvas, Rect r) {
    final p = Paint()
      ..color = accent
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.4;
    final l = math.min(r.width, r.height) * .25;
    final path = Path()
      ..moveTo(r.left, r.top + l)
      ..lineTo(r.left, r.top)
      ..lineTo(r.left + l, r.top)
      ..moveTo(r.right - l, r.top)
      ..lineTo(r.right, r.top)
      ..lineTo(r.right, r.top + l)
      ..moveTo(r.right, r.bottom - l)
      ..lineTo(r.right, r.bottom)
      ..lineTo(r.right - l, r.bottom)
      ..moveTo(r.left + l, r.bottom)
      ..lineTo(r.left, r.bottom)
      ..lineTo(r.left, r.bottom - l);
    canvas.drawPath(path, p);
  }

  void _skeleton(Canvas canvas, double x, double top, double h, double w) {
    final p = Paint()
      ..color = Colors.white.o(.9)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.3
      ..strokeCap = StrokeCap.round;
    Offset o(double dx, double dy) => Offset(x + dx * w, top + dy * h);

    canvas.drawCircle(o(0, .07), h * .07, p);
    final pelvis = o(0, .56);
    canvas.drawLine(o(0, .14), pelvis, p);
    canvas.drawLine(o(-.5, .20), o(.5, .20), p);
    for (final sgn in [-1.0, 1.0]) {
      final path = Path()
        ..moveTo(o(.5 * sgn, .20).dx, o(.5 * sgn, .20).dy)
        ..lineTo(o(.62 * sgn, .36).dx, o(.62 * sgn, .36).dy)
        ..lineTo(o(.5 * sgn, .50).dx, o(.5 * sgn, .50).dy);
      canvas.drawPath(path, p);
      final leg = Path()
        ..moveTo(pelvis.dx, pelvis.dy)
        ..lineTo(o(.2 * sgn, .78).dx, o(.2 * sgn, .78).dy)
        ..lineTo(o(.22 * sgn, .98).dx, o(.22 * sgn, .98).dy);
      canvas.drawPath(leg, p);
    }
  }

  void _radar(Canvas canvas, Size size) {
    final c = Offset(size.width - 30, 30);
    const r = 24.0;
    canvas.drawCircle(c, r, Paint()..color = Colors.black.o(.55));
    final outer = Paint()
      ..color = accent.o(.6)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1;
    final inner = Paint()
      ..color = accent.o(.25)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1;
    canvas.drawCircle(c, r, outer);
    canvas.drawCircle(c, r * .5, inner);

    final a = sweep * 2 * math.pi;
    canvas.drawArc(Rect.fromCircle(center: c, radius: r), a - .6, .6, true,
        Paint()..color = accent.o(.28));
    canvas.drawLine(c, c + Offset(math.cos(a), math.sin(a)) * r, outer);

    for (final p in _people) {
      final (fx, _, _, dist) = p;
      final dot = c + Offset((fx - .5) * r * 1.6, -dist / 80 * r * .85);
      canvas.drawCircle(dot, 2.2, Paint()..color = accent);
    }
    canvas.drawCircle(c, 2, Paint()..color = Palette.text);
  }

  @override
  bool shouldRepaint(covariant _VisualPainter old) => true;
}

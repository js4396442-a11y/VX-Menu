import 'package:flutter/material.dart';
import '../core/theme.dart';

/// Slider com rótulo e valor.
/// [live] = false: só chama [onChanged] ao soltar (útil para valores que
/// redimensionam a própria janela, como a escala da interface).
class NeonSlider extends StatefulWidget {
  const NeonSlider({
    super.key,
    required this.label,
    required this.value,
    required this.min,
    required this.max,
    required this.onChanged,
    this.onChangeEnd,
    this.format,
    this.enabled = true,
    this.live = true,
  });

  final String label;
  final double value, min, max;
  final ValueChanged<double> onChanged;
  final ValueChanged<double>? onChangeEnd;
  final String Function(double)? format;
  final bool enabled, live;

  @override
  State<NeonSlider> createState() => _NeonSliderState();
}

class _NeonSliderState extends State<NeonSlider> {
  double? _drag;

  @override
  Widget build(BuildContext context) {
    final accent = Theme.of(context).colorScheme.primary;
    final v = (_drag ?? widget.value).clamp(widget.min, widget.max);
    final text = widget.format?.call(v) ?? v.toStringAsFixed(0);

    return Opacity(
      opacity: widget.enabled ? 1 : .38,
      child: Column(children: [
        Row(children: [
          Text(widget.label,
              style: const TextStyle(
                  fontSize: 12.5, fontWeight: FontWeight.w600)),
          const Spacer(),
          Text(text,
              style: TextStyle(
                  fontSize: 11.5,
                  color: accent,
                  fontWeight: FontWeight.w700)),
        ]),
        SizedBox(
          height: 30,
          child: Slider(
            value: v,
            min: widget.min,
            max: widget.max,
            onChanged: widget.enabled
                ? (x) {
                    if (widget.live) {
                      widget.onChanged(x);
                    } else {
                      setState(() => _drag = x);
                    }
                  }
                : null,
            onChangeEnd: widget.enabled
                ? (x) {
                    if (!widget.live) {
                      widget.onChanged(x);
                      setState(() => _drag = null);
                    }
                    widget.onChangeEnd?.call(x);
                  }
                : null,
          ),
        ),
      ]),
    );
  }
}

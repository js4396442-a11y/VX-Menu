import 'package:flutter/material.dart';

import '../core/constants.dart';
import '../state/menu_scope.dart';
import '../widgets/aim_preview.dart';
import '../widgets/neon_card.dart';
import '../widgets/neon_selector.dart';
import '../widgets/neon_slider.dart';
import '../widgets/neon_toggle.dart';

class AimPage extends StatelessWidget {
  const AimPage({super.key});

  @override
  Widget build(BuildContext context) {
    final s = MenuScope.of(context);
    final on = s.flag(K.aimOn);

    return ListView(
      primary: false,
      physics: const BouncingScrollPhysics(),
      padding: const EdgeInsets.all(12),
      children: [
        NeonCard(
          child: NeonToggle(
            label: 'Aim Assist',
            hint: 'Simulação na prévia abaixo',
            icon: Icons.gps_fixed_rounded,
            value: on,
            onChanged: (v) => s.set(K.aimOn, v),
          ),
        ),
        const NeonCard(title: 'PRÉVIA (SIMULAÇÃO LOCAL)', child: AimPreview()),
        NeonCard(
          title: 'AJUSTES',
          child: Column(children: [
            NeonSlider(
              label: 'FOV',
              value: s.dbl(K.aimFov),
              min: 10,
              max: 180,
              enabled: on,
              format: (v) => '${v.round()}°',
              onChanged: (v) => s.set(K.aimFov, v, persist: false),
              onChangeEnd: (_) => s.save(K.aimFov),
            ),
            const SizedBox(height: 6),
            NeonSlider(
              label: 'Smoothness',
              value: s.dbl(K.aimSmooth),
              min: 0,
              max: 100,
              enabled: on,
              format: (v) => '${v.round()}%',
              onChanged: (v) => s.set(K.aimSmooth, v, persist: false),
              onChangeEnd: (_) => s.save(K.aimSmooth),
            ),
            const SizedBox(height: 12),
            Opacity(
              opacity: on ? 1 : .38,
              child: IgnorePointer(
                ignoring: !on,
                child: Column(children: [
                  NeonSelector(
                    label: 'Target Selection',
                    options: kTargetOptions,
                    selected: s.idx(K.aimTarget),
                    onChanged: (i) => s.set(K.aimTarget, i),
                  ),
                  const SizedBox(height: 12),
                  NeonSelector(
                    label: 'Aim Mode',
                    options: kModeOptions,
                    selected: s.idx(K.aimMode),
                    onChanged: (i) => s.set(K.aimMode, i),
                  ),
                ]),
              ),
            ),
          ]),
        ),
      ],
    );
  }
}

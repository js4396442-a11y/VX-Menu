import 'package:flutter/material.dart';

import '../core/constants.dart';
import '../state/menu_scope.dart';
import '../widgets/neon_card.dart';
import '../widgets/neon_toggle.dart';
import '../widgets/visual_preview.dart';

class VisualPage extends StatelessWidget {
  const VisualPage({super.key});

  @override
  Widget build(BuildContext context) {
    final s = MenuScope.of(context);
    final esp = s.flag(K.espOn);

    Widget toggle(String label, String key, IconData icon,
        {bool gated = true}) {
      return NeonToggle(
        label: label,
        icon: icon,
        value: s.flag(key),
        enabled: !gated || esp,
        onChanged: (v) => s.set(key, v),
      );
    }

    return ListView(
      primary: false,
      physics: const BouncingScrollPhysics(),
      padding: const EdgeInsets.all(12),
      children: [
        NeonCard(
          child: NeonToggle(
            label: 'ESP',
            hint: 'Liga/desliga os itens abaixo',
            icon: Icons.visibility_rounded,
            value: esp,
            onChanged: (v) => s.set(K.espOn, v),
          ),
        ),
        const NeonCard(title: 'PRÉVIA (SIMULAÇÃO LOCAL)', child: VisualPreview()),
        NeonCard(
          title: 'ELEMENTOS',
          child: Column(children: [
            toggle('Player Box', K.box, Icons.crop_free_rounded),
            const NeonDivider(),
            toggle('Skeleton', K.skeleton, Icons.accessibility_new_rounded),
            const NeonDivider(),
            toggle('Name Display', K.name, Icons.badge_outlined),
            const NeonDivider(),
            toggle('Distance Display', K.distance, Icons.straighten_rounded),
            const NeonDivider(),
            toggle('Radar', K.radar, Icons.radar_rounded, gated: false),
          ]),
        ),
      ],
    );
  }
}

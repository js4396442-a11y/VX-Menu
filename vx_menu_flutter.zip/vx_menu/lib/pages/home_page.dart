import 'package:flutter/material.dart';

import '../core/constants.dart';
import '../core/theme.dart';
import '../state/menu_scope.dart';
import '../widgets/neon_card.dart';
import '../widgets/neon_selector.dart';
import '../widgets/pulse_dot.dart';

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    final s = MenuScope.of(context);
    final accent = Theme.of(context).colorScheme.primary;

    return ListView(
      primary: false,
      physics: const BouncingScrollPhysics(),
      padding: const EdgeInsets.all(12),
      children: [
        NeonCard(
          title: 'STATUS',
          child: Row(children: [
            const _Stat(label: 'INTERFACE', value: 'ATIVA', dot: true),
            const _Stat(label: 'MODO', value: 'DEMO'),
            _Stat(label: 'MÓDULOS', value: '${s.activeModules}/7'),
          ]),
        ),
        NeonCard(
          title: 'PERFIL DE CONFIGURAÇÃO',
          child: NeonSelector(
            label: 'Perfil',
            options: [for (final p in kProfiles) p.name],
            selected: s.idx(K.profile),
            onChanged: s.applyProfile,
          ),
        ),
        NeonCard(
          title: 'INDICADORES',
          child: Column(children: [
            _Bar('FOV', s.dbl(K.aimFov) / 180, '${s.dbl(K.aimFov).round()}°'),
            _Bar('SMOOTH', s.dbl(K.aimSmooth) / 100,
                '${s.dbl(K.aimSmooth).round()}%'),
            _Bar('OPACIDADE', s.dbl(K.opacity),
                '${(s.dbl(K.opacity) * 100).round()}%'),
          ]),
        ),
        const NeonCard(
          title: 'APLICATIVO',
          child: Column(children: [
            _Info('Versão', '1.0.0'),
            _Info('Plataforma', 'Flutter · Android'),
            _Info('Dados', 'Preferências locais'),
            _Info('Escopo',
                'Interface independente. Não acessa jogos, processos nem a memória de outros apps.'),
          ]),
        ),
        OutlinedButton.icon(
          onPressed: s.resetAll,
          icon: const Icon(Icons.restart_alt_rounded, size: 16),
          label: const Text('Restaurar padrões'),
          style: OutlinedButton.styleFrom(
            foregroundColor: accent,
            side: BorderSide(color: accent.o(.6)),
          ),
        ),
      ],
    );
  }
}

class _Stat extends StatelessWidget {
  const _Stat({required this.label, required this.value, this.dot = false});
  final String label, value;
  final bool dot;

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(label,
            style: const TextStyle(
                fontSize: 9, letterSpacing: 1.2, color: Palette.muted)),
        const SizedBox(height: 4),
        Row(children: [
          if (dot) ...[const PulseDot(), const SizedBox(width: 6)],
          Text(value,
              style:
                  const TextStyle(fontSize: 13, fontWeight: FontWeight.w800)),
        ]),
      ]),
    );
  }
}

class _Bar extends StatelessWidget {
  const _Bar(this.label, this.value, this.text);
  final String label, text;
  final double value;

  @override
  Widget build(BuildContext context) {
    final s = MenuScope.of(context);
    final accent = Theme.of(context).colorScheme.primary;
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: Row(children: [
        SizedBox(
          width: 78,
          child: Text(label,
              style: const TextStyle(fontSize: 10, color: Palette.muted)),
        ),
        Expanded(
          child: TweenAnimationBuilder<double>(
            tween: Tween(end: value.clamp(0.0, 1.0)),
            duration: s.d(300),
            builder: (_, v, __) => ClipRRect(
              borderRadius: BorderRadius.circular(3),
              child: LinearProgressIndicator(
                value: v,
                minHeight: 5,
                color: accent,
                backgroundColor: Palette.line,
              ),
            ),
          ),
        ),
        SizedBox(
          width: 44,
          child: Text(text,
              textAlign: TextAlign.right,
              style: const TextStyle(fontSize: 10.5, fontWeight: FontWeight.w700)),
        ),
      ]),
    );
  }
}

class _Info extends StatelessWidget {
  const _Info(this.k, this.v);
  final String k, v;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        SizedBox(
          width: 78,
          child: Text(k,
              style: const TextStyle(fontSize: 10, color: Palette.muted)),
        ),
        Expanded(child: Text(v, style: const TextStyle(fontSize: 10.5))),
      ]),
    );
  }
}

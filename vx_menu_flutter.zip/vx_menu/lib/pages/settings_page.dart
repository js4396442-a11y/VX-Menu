import 'package:flutter/material.dart';

import '../core/constants.dart';
import '../core/theme.dart';
import '../state/menu_scope.dart';
import '../widgets/neon_card.dart';
import '../widgets/neon_selector.dart';
import '../widgets/neon_slider.dart';
import '../widgets/neon_toggle.dart';

class SettingsPage extends StatelessWidget {
  const SettingsPage({super.key});

  @override
  Widget build(BuildContext context) {
    final s = MenuScope.of(context);

    return ListView(
      primary: false,
      physics: const BouncingScrollPhysics(),
      padding: const EdgeInsets.all(12),
      children: [
        NeonCard(
          title: 'INTERFACE',
          child: Column(children: [
            NeonSlider(
              label: 'Interface Scale',
              value: s.dbl(K.scale),
              min: 0.8,
              max: 1.3,
              live: false,
              format: (v) => '${v.toStringAsFixed(2)}×',
              onChanged: (v) => s.set(K.scale, v),
            ),
            const SizedBox(height: 6),
            NeonSlider(
              label: 'Opacidade',
              value: s.dbl(K.opacity),
              min: 0.5,
              max: 1.0,
              format: (v) => '${(v * 100).round()}%',
              onChanged: (v) => s.set(K.opacity, v, persist: false),
              onChangeEnd: (_) => s.save(K.opacity),
            ),
            const SizedBox(height: 12),
            NeonSelector(
              label: 'Tema',
              options: [for (final a in kAccents) a.name],
              colors: [for (final a in kAccents) a.color],
              selected: s.idx(K.theme),
              onChanged: (i) => s.set(K.theme, i),
            ),
            const SizedBox(height: 12),
            NeonSelector(
              label: 'Posição do menu',
              options: [for (final p in kPositions) p.name],
              selected: s.idx(K.pos),
              onChanged: s.applyPosition,
            ),
            const NeonDivider(),
            NeonToggle(
              label: 'Animações',
              icon: Icons.animation_rounded,
              value: s.flag(K.anim),
              onChanged: (v) => s.set(K.anim, v),
            ),
          ]),
        ),
        NeonCard(
          title: 'HOTKEYS',
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            NeonSelector(
              label: 'Abrir / minimizar menu',
              options: kHotkeyLabels,
              selected: s.idx(K.keyMenu),
              onChanged: (i) => s.set(K.keyMenu, i),
            ),
            const SizedBox(height: 12),
            NeonSelector(
              label: 'Aim Assist (liga/desliga)',
              options: kHotkeyLabels,
              selected: s.idx(K.keyAim),
              onChanged: (i) => s.set(K.keyAim, i),
            ),
            const SizedBox(height: 10),
            const Text(
              'Valem apenas dentro deste app, com teclado físico (emulador ou Bluetooth).',
              style: TextStyle(fontSize: 9.5, color: Palette.muted),
            ),
          ]),
        ),
      ],
    );
  }
}

import 'package:flutter/material.dart';

import '../core/theme.dart';
import '../pages/aim_page.dart';
import '../pages/home_page.dart';
import '../pages/settings_page.dart';
import '../pages/visual_page.dart';
import '../state/menu_scope.dart';

const _pages = <Widget>[HomePage(), AimPage(), VisualPage(), SettingsPage()];

const _tabs = <(IconData, String)>[
  (Icons.dashboard_outlined, 'HOME'),
  (Icons.gps_fixed_rounded, 'AIM'),
  (Icons.visibility_outlined, 'VISUAL'),
  (Icons.tune_rounded, 'SETTINGS'),
];

/// Conteúdo da janela (320×480 base). Arrastar/escala ficam a cargo do shell.
class MenuWindow extends StatelessWidget {
  const MenuWindow({
    super.key,
    required this.tab,
    required this.onTab,
    required this.onMinimize,
    required this.onDragStart,
    required this.onDrag,
    required this.onDragEnd,
  });

  final int tab;
  final ValueChanged<int> onTab;
  final VoidCallback onMinimize, onDragStart, onDragEnd;
  final ValueChanged<Offset> onDrag;

  @override
  Widget build(BuildContext context) {
    final s = MenuScope.of(context);
    final accent = Theme.of(context).colorScheme.primary;

    return DecoratedBox(
      decoration: BoxDecoration(
        color: Palette.panel,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: accent.o(.4)),
        boxShadow: [
          BoxShadow(color: accent.o(.20), blurRadius: 24),
          const BoxShadow(color: Colors.black54, blurRadius: 16),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(14),
        child: Column(children: [
          // Cabeçalho = alça de arraste
          GestureDetector(
            behavior: HitTestBehavior.opaque,
            onPanStart: (_) => onDragStart(),
            onPanUpdate: (d) => onDrag(d.delta),
            onPanEnd: (_) => onDragEnd(),
            onPanCancel: onDragEnd,
            child: Container(
              height: 44,
              padding: const EdgeInsets.only(left: 14, right: 6),
              decoration: const BoxDecoration(
                border: Border(bottom: BorderSide(color: Palette.line)),
              ),
              child: Row(children: [
                Icon(Icons.bolt_rounded, size: 18, color: accent),
                const SizedBox(width: 6),
                const Text('VX//MENU',
                    style: TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.w800,
                        letterSpacing: 2.5)),
                const SizedBox(width: 8),
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(4),
                    border: Border.all(color: accent.o(.6)),
                  ),
                  child: Text('DEMO',
                      style: TextStyle(
                          fontSize: 8.5,
                          color: accent,
                          fontWeight: FontWeight.w700)),
                ),
                const Spacer(),
                const Icon(Icons.drag_indicator_rounded,
                    size: 18, color: Palette.muted),
                GestureDetector(
                  behavior: HitTestBehavior.opaque,
                  onTap: onMinimize,
                  child: const Padding(
                    padding: EdgeInsets.all(8),
                    child: Icon(Icons.remove_rounded,
                        size: 20, color: Palette.text),
                  ),
                ),
              ]),
            ),
          ),
          Expanded(
            child: AnimatedSwitcher(
              duration: s.d(200),
              child: KeyedSubtree(
                key: ValueKey(tab),
                child: _pages[tab],
              ),
            ),
          ),
          _TabBar(tab: tab, onTab: onTab),
        ]),
      ),
    );
  }
}

class _TabBar extends StatelessWidget {
  const _TabBar({required this.tab, required this.onTab});
  final int tab;
  final ValueChanged<int> onTab;

  @override
  Widget build(BuildContext context) {
    final s = MenuScope.of(context);
    final accent = Theme.of(context).colorScheme.primary;

    return Container(
      height: 54,
      decoration: const BoxDecoration(
        color: Palette.bg,
        border: Border(top: BorderSide(color: Palette.line)),
      ),
      child: Row(children: [
        for (var i = 0; i < _tabs.length; i++)
          Expanded(
            child: GestureDetector(
              behavior: HitTestBehavior.opaque,
              onTap: () => onTab(i),
              child: AnimatedContainer(
                duration: s.d(200),
                decoration: BoxDecoration(
                  border: Border(
                    top: BorderSide(
                        color: i == tab ? accent : Colors.transparent,
                        width: 2),
                  ),
                  boxShadow: i == tab
                      ? [BoxShadow(color: accent.o(.18), blurRadius: 12)]
                      : const [],
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(_tabs[i].$1,
                        size: 18,
                        color: i == tab ? accent : Palette.muted),
                    const SizedBox(height: 3),
                    Text(_tabs[i].$2,
                        style: TextStyle(
                          fontSize: 8.5,
                          letterSpacing: 1,
                          fontWeight: FontWeight.w700,
                          color: i == tab ? Palette.text : Palette.muted,
                        )),
                  ],
                ),
              ),
            ),
          ),
      ]),
    );
  }
}

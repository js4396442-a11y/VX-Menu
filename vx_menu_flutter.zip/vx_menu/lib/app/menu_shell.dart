import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../core/constants.dart';
import '../core/paint_utils.dart';
import '../core/theme.dart';
import '../state/menu_scope.dart';
import 'menu_window.dart';

/// Palco + janela flutuante. A janela (ou o botão minimizado) é arrastável
/// dentro do app; a posição é guardada como fração da área livre, então
/// funciona em qualquer tamanho de tela.
class MenuShell extends StatefulWidget {
  const MenuShell({super.key});
  @override
  State<MenuShell> createState() => _MenuShellState();
}

class _MenuShellState extends State<MenuShell> {
  static const _baseW = 320.0, _baseH = 480.0, _bubble = 58.0, _margin = 8.0;

  bool _dragging = false;
  int _tab = 0;
  Size _free = Size.zero;

  String _prefix(bool minimized) => minimized ? 'bub' : 'win';

  KeyEventResult _onKey(FocusNode node, KeyEvent event) {
    if (event is! KeyDownEvent) return KeyEventResult.ignored;
    final s = MenuScope.read(context);
    if (event.logicalKey == kHotkeyKeys[s.idx(K.keyMenu)]) {
      s.set(K.minimized, !s.flag(K.minimized));
      return KeyEventResult.handled;
    }
    if (event.logicalKey == kHotkeyKeys[s.idx(K.keyAim)]) {
      s.set(K.aimOn, !s.flag(K.aimOn));
      return KeyEventResult.handled;
    }
    return KeyEventResult.ignored;
  }

  void _dragBy(Offset d) {
    final s = MenuScope.read(context);
    final p = _prefix(s.flag(K.minimized));
    if (_free.width > 0) {
      s.set('$p.fx', (s.dbl('$p.fx') + d.dx / _free.width).clamp(0.0, 1.0),
          persist: false);
    }
    if (_free.height > 0) {
      s.set('$p.fy', (s.dbl('$p.fy') + d.dy / _free.height).clamp(0.0, 1.0),
          persist: false);
    }
  }

  void _dragStart() => setState(() => _dragging = true);

  void _dragEnd() {
    if (!_dragging) return;
    setState(() => _dragging = false);
    final s = MenuScope.read(context);
    final p = _prefix(s.flag(K.minimized));
    s.save('$p.fx');
    s.save('$p.fy');
  }

  @override
  Widget build(BuildContext context) {
    final s = MenuScope.of(context);
    final minimized = s.flag(K.minimized);
    final p = _prefix(minimized);

    return Focus(
      autofocus: true,
      onKeyEvent: _onKey,
      child: Scaffold(
        resizeToAvoidBottomInset: false,
        body: LayoutBuilder(builder: (context, c) {
          final insets = MediaQuery.paddingOf(context);
          final availW =
              math.max(0.0, c.maxWidth - insets.horizontal - _margin * 2);
          final availH =
              math.max(0.0, c.maxHeight - insets.vertical - _margin * 2);
          final scale = math.min(
              s.dbl(K.scale), math.min(availW / _baseW, availH / _baseH));
          final size = minimized
              ? const Size(_bubble, _bubble)
              : Size(_baseW * scale, _baseH * scale);

          _free = Size(math.max(0.0, availW - size.width),
              math.max(0.0, availH - size.height));
          final left = insets.left + _margin + s.dbl('$p.fx') * _free.width;
          final top = insets.top + _margin + s.dbl('$p.fy') * _free.height;
          final dragScale = minimized ? 1.0 : scale;

          return Stack(children: [
            const Positioned.fill(child: _Stage()),
            AnimatedPositioned(
              duration: (_dragging || !s.anim)
                  ? Duration.zero
                  : const Duration(milliseconds: 280),
              curve: Curves.easeOutCubic,
              left: left,
              top: top,
              width: size.width,
              height: size.height,
              child: AnimatedSwitcher(
                duration: s.d(200),
                child: minimized
                    ? _Bubble(
                        key: const ValueKey('bubble'),
                        onTap: () => s.set(K.minimized, false),
                        onDragStart: _dragStart,
                        onDrag: _dragBy,
                        onDragEnd: _dragEnd,
                      )
                    : Opacity(
                        key: const ValueKey('window'),
                        opacity: s.dbl(K.opacity),
                        child: FittedBox(
                          fit: BoxFit.contain,
                          child: SizedBox(
                            width: _baseW,
                            height: _baseH,
                            child: MenuWindow(
                              tab: _tab,
                              onTab: (i) => setState(() => _tab = i),
                              onMinimize: () => s.set(K.minimized, true),
                              onDragStart: _dragStart,
                              // delta chega em coordenadas locais (sem escala)
                              onDrag: (d) => _dragBy(d * dragScale),
                              onDragEnd: _dragEnd,
                            ),
                          ),
                        ),
                      ),
              ),
            ),
          ]);
        }),
      ),
    );
  }
}

class _Bubble extends StatelessWidget {
  const _Bubble({
    super.key,
    required this.onTap,
    required this.onDragStart,
    required this.onDrag,
    required this.onDragEnd,
  });

  final VoidCallback onTap, onDragStart, onDragEnd;
  final ValueChanged<Offset> onDrag;

  @override
  Widget build(BuildContext context) {
    final accent = Theme.of(context).colorScheme.primary;
    return GestureDetector(
      onTap: onTap,
      onPanStart: (_) => onDragStart(),
      onPanUpdate: (d) => onDrag(d.delta),
      onPanEnd: (_) => onDragEnd(),
      onPanCancel: onDragEnd,
      child: Container(
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: Palette.panel,
          border: Border.all(color: accent, width: 1.5),
          boxShadow: [BoxShadow(color: accent.o(.45), blurRadius: 16)],
        ),
        child: Icon(Icons.bolt_rounded, color: accent, size: 28),
      ),
    );
  }
}

/// Fundo neutro de demonstração (grade + vinheta). Não representa nenhum jogo.
class _Stage extends StatelessWidget {
  const _Stage();

  @override
  Widget build(BuildContext context) {
    final accent = Theme.of(context).colorScheme.primary;
    return Stack(children: [
      Positioned.fill(child: CustomPaint(painter: _StagePainter(accent))),
      const Center(
        child: Padding(
          padding: EdgeInsets.all(32),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Text('ÁREA DE DEMONSTRAÇÃO',
                style: TextStyle(
                    fontSize: 12, letterSpacing: 3, color: Palette.muted)),
            SizedBox(height: 6),
            Text('Interface independente · sem conexão com jogos',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 10, color: Palette.line)),
          ]),
        ),
      ),
    ]);
  }
}

class _StagePainter extends CustomPainter {
  const _StagePainter(this.accent);
  final Color accent;

  @override
  void paint(Canvas canvas, Size size) {
    final rect = Offset.zero & size;
    canvas.drawRect(
      rect,
      Paint()
        ..shader = RadialGradient(
          center: const Alignment(0, .2),
          radius: 1.1,
          colors: [accent.o(.10), Palette.bg],
        ).createShader(rect),
    );
    paintGrid(canvas, size, step: 32);
  }

  @override
  bool shouldRepaint(covariant _StagePainter old) => old.accent != accent;
}

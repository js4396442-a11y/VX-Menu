import 'package:flutter/foundation.dart';

import '../core/constants.dart';
import '../core/prefs_store.dart';

/// Estado único do menu: todos os valores vivem num mapa tipado por
/// [kDefaults] e são persistidos localmente a cada alteração.
class MenuState extends ChangeNotifier {
  MenuState(this._store) {
    for (final e in kDefaults.entries) {
      final raw = _store.read(e.key);
      _v[e.key] = (raw != null && raw.runtimeType == e.value.runtimeType)
          ? raw
          : e.value;
    }
  }

  final PrefsStore _store;
  final Map<String, Object> _v = {};

  bool flag(String k) => _v[k] as bool;
  double dbl(String k) => _v[k] as double;
  int idx(String k) => _v[k] as int;

  bool get anim => flag(K.anim);
  Duration d([int ms = 220]) =>
      anim ? Duration(milliseconds: ms) : Duration.zero;

  int get activeModules => kModuleKeys.where(flag).length;

  void set(String k, Object v, {bool persist = true}) {
    if (_v[k] == v) return;
    _v[k] = v;
    if (persist) _store.write(k, v);
    notifyListeners();
  }

  void save(String k) => _store.write(k, _v[k]!);

  void _apply(Map<String, Object> values) {
    values.forEach((k, v) {
      _v[k] = v;
      _store.write(k, v);
    });
    notifyListeners();
  }

  void applyProfile(int i) =>
      _apply({...kProfiles[i].values, K.profile: i});

  void applyPosition(int i) {
    final p = kPositions[i];
    _apply({
      K.pos: i,
      K.winX: p.fx,
      K.winY: p.fy,
      K.bubX: p.fx,
      K.bubY: p.fy,
    });
  }

  void resetAll() => _apply(Map<String, Object>.from(kDefaults));
}

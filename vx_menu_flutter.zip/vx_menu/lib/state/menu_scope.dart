import 'package:flutter/widgets.dart';
import 'menu_state.dart';

class MenuScope extends InheritedNotifier<MenuState> {
  const MenuScope({super.key, required MenuState state, required super.child})
      : super(notifier: state);

  /// Lê e reconstrói quando o estado muda.
  static MenuState of(BuildContext context) =>
      context.dependOnInheritedWidgetOfExactType<MenuScope>()!.notifier!;

  /// Lê sem registrar dependência (use em callbacks).
  static MenuState read(BuildContext context) =>
      context.getInheritedWidgetOfExactType<MenuScope>()!.notifier!;
}

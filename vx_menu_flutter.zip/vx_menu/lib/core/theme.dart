import 'package:flutter/material.dart';

class AccentTheme {
  const AccentTheme(this.name, this.color);
  final String name;
  final Color color;
}

const kAccents = <AccentTheme>[
  AccentTheme('Vermelho neon', Color(0xFFFF1744)),
  AccentTheme('Ciano', Color(0xFF00E5FF)),
  AccentTheme('Verde', Color(0xFF00E676)),
  AccentTheme('Violeta', Color(0xFFB388FF)),
];

abstract final class Palette {
  static const bg = Color(0xFF0A0A0C);
  static const panel = Color(0xFF121216);
  static const card = Color(0xFF1A1A20);
  static const line = Color(0xFF2A2A33);
  static const text = Color(0xFFECECF1);
  static const muted = Color(0xFF8B8B98);
}

extension ColorOpacity on Color {
  /// Atalho: cor com opacidade [v] (0..1).
  Color o(double v) => withAlpha((v.clamp(0.0, 1.0) * 255).round());
}

final Map<int, ThemeData> _cache = {};

ThemeData buildTheme(int accentIndex) {
  return _cache.putIfAbsent(accentIndex, () {
    final accent = kAccents[accentIndex].color;
    final scheme = ColorScheme.dark(
      primary: accent,
      onPrimary: Colors.black,
      secondary: accent,
      surface: Palette.panel,
      onSurface: Palette.text,
    );
    return ThemeData(
      useMaterial3: true,
      brightness: Brightness.dark,
      colorScheme: scheme,
      scaffoldBackgroundColor: Palette.bg,
      fontFamily: 'monospace',
      splashFactory: NoSplash.splashFactory,
      sliderTheme: SliderThemeData(
        trackHeight: 3,
        activeTrackColor: accent,
        inactiveTrackColor: Palette.line,
        thumbColor: accent,
        overlayColor: accent.o(.15),
        thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 7),
        overlayShape: const RoundSliderOverlayShape(overlayRadius: 14),
      ),
    );
  });
}

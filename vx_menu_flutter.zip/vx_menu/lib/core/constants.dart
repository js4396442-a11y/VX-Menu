import 'package:flutter/services.dart';

/// Chaves de preferências (também usadas como identificadores de estado).
abstract final class K {
  // AIM (simulação dentro do app)
  static const aimOn = 'aim.on';
  static const aimFov = 'aim.fov';
  static const aimSmooth = 'aim.smooth';
  static const aimTarget = 'aim.target';
  static const aimMode = 'aim.mode';
  // VISUAL (simulação dentro do app)
  static const espOn = 'vis.esp';
  static const box = 'vis.box';
  static const skeleton = 'vis.skeleton';
  static const name = 'vis.name';
  static const distance = 'vis.distance';
  static const radar = 'vis.radar';
  // SETTINGS
  static const scale = 'ui.scale';
  static const opacity = 'ui.opacity';
  static const theme = 'ui.theme';
  static const pos = 'ui.pos';
  static const anim = 'ui.anim';
  static const keyMenu = 'key.menu';
  static const keyAim = 'key.aim';
  // APP
  static const profile = 'app.profile';
  static const minimized = 'win.min';
  static const winX = 'win.fx';
  static const winY = 'win.fy';
  static const bubX = 'bub.fx';
  static const bubY = 'bub.fy';
}

const Map<String, Object> kDefaults = {
  K.aimOn: false,
  K.aimFov: 80.0,
  K.aimSmooth: 50.0,
  K.aimTarget: 0,
  K.aimMode: 0,
  K.espOn: false,
  K.box: true,
  K.skeleton: false,
  K.name: true,
  K.distance: true,
  K.radar: false,
  K.scale: 1.0,
  K.opacity: 0.95,
  K.theme: 0,
  K.pos: 1,
  K.anim: true,
  K.keyMenu: 0,
  K.keyAim: 1,
  K.profile: 0,
  K.minimized: false,
  K.winX: 1.0,
  K.winY: 0.0,
  K.bubX: 1.0,
  K.bubY: 0.0,
};

/// Os 7 módulos contados no dashboard.
const kModuleKeys = [
  K.aimOn, K.espOn, K.box, K.skeleton, K.name, K.distance, K.radar,
];

const kTargetOptions = ['Mais próximo da mira', 'Menor distância', 'Menor vida'];
const kModeOptions = ['Contínuo', 'Segurar', 'Alternar'];

class MenuPosition {
  const MenuPosition(this.name, this.fx, this.fy);
  final String name;
  final double fx, fy;
}

const kPositions = [
  MenuPosition('Topo esq.', 0, 0),
  MenuPosition('Topo dir.', 1, 0),
  MenuPosition('Centro', .5, .5),
  MenuPosition('Base esq.', 0, 1),
  MenuPosition('Base dir.', 1, 1),
];

class MenuProfile {
  const MenuProfile(this.name, this.values);
  final String name;
  final Map<String, Object> values;
}

const kProfiles = [
  MenuProfile('Padrão', {
    K.aimOn: false, K.aimFov: 80.0, K.aimSmooth: 50.0,
    K.espOn: false, K.box: true, K.skeleton: false,
    K.name: true, K.distance: true, K.radar: false,
  }),
  MenuProfile('Equilibrado', {
    K.aimOn: true, K.aimFov: 60.0, K.aimSmooth: 70.0,
    K.espOn: true, K.box: true, K.skeleton: false,
    K.name: true, K.distance: true, K.radar: true,
  }),
  MenuProfile('Completo', {
    K.aimOn: true, K.aimFov: 140.0, K.aimSmooth: 35.0,
    K.espOn: true, K.box: true, K.skeleton: true,
    K.name: true, K.distance: true, K.radar: true,
  }),
];

const kHotkeyLabels = ['F1', 'F2', 'F3', 'F4', 'Insert', 'Home'];
final kHotkeyKeys = <LogicalKeyboardKey>[
  LogicalKeyboardKey.f1,
  LogicalKeyboardKey.f2,
  LogicalKeyboardKey.f3,
  LogicalKeyboardKey.f4,
  LogicalKeyboardKey.insert,
  LogicalKeyboardKey.home,
];

import 'package:flutter/material.dart';
import 'theme.dart';

void paintText(
  Canvas canvas,
  String text,
  Offset at, {
  double size = 9,
  Color color = Palette.muted,
  FontWeight weight = FontWeight.w500,
  bool center = true,
}) {
  final tp = TextPainter(
    text: TextSpan(
      text: text,
      style: TextStyle(
          fontSize: size, color: color, fontWeight: weight, fontFamily: 'monospace'),
    ),
    textDirection: TextDirection.ltr,
  )..layout();
  tp.paint(canvas, center ? at - Offset(tp.width / 2, tp.height / 2) : at);
}

void paintGrid(Canvas canvas, Size size, {double step = 20}) {
  final p = Paint()
    ..color = Palette.line.o(.5)
    ..strokeWidth = 1;
  for (double x = 0; x <= size.width; x += step) {
    canvas.drawLine(Offset(x, 0), Offset(x, size.height), p);
  }
  for (double y = 0; y <= size.height; y += step) {
    canvas.drawLine(Offset(0, y), Offset(size.width, y), p);
  }
}

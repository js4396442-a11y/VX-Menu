import 'package:shared_preferences/shared_preferences.dart';

/// Camada fina sobre SharedPreferences (persistência local).
class PrefsStore {
  PrefsStore(this._p);
  final SharedPreferences _p;

  static Future<PrefsStore> open() async =>
      PrefsStore(await SharedPreferences.getInstance());

  Object? read(String key) => _p.get(key);

  Future<void> write(String key, Object value) async {
    if (value is bool) {
      await _p.setBool(key, value);
    } else if (value is double) {
      await _p.setDouble(key, value);
    } else if (value is int) {
      await _p.setInt(key, value);
    }
  }
}
